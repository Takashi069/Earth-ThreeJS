put earthspec32k.ssc into	[celestiadir]\extras\
put earthspec32k.ctx into	[celestiadir]\extras\textures\medres\
put the level#-dirs into	[celestiadir]\extras\textures\medres\earthspec32k\

You probably want to edit the ssc file to combine the specular texture with your favourite other textures

Run Celestia, right-click Earth, and select earthspec32k under "alternate surfaces"

Special thanks to Fridger for sharing his VTscripts

Buzz, July 2004